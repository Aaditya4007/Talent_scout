import streamlit as st
from database import save_candidate
from interview_manager import InterviewManager
from translations import get_text
import json

def show_candidate_registration():
    st.title("👋 " + get_text("Candidate Registration"))
    st.markdown("### Let's get to know you better")

    with st.form("candidate_registration", clear_on_submit=False):
        col1, col2 = st.columns(2)

        with col1:
            full_name = st.text_input(
                "👤 " + get_text("Full Name"),
                key="full_name",
                placeholder="John Doe"
            )

            email = st.text_input(
                "📧 " + get_text("Email"),
                key="email",
                placeholder="john@example.com"
            )

            phone = st.text_input(
                "📱 " + get_text("Phone"),
                key="phone",
                placeholder="+1234567890"
            )

        with col2:
            experience_years = st.number_input(
                "⏳ " + get_text("Years of Experience"),
                min_value=0,
                max_value=50,
                help="Select your years of professional experience"
            )

            desired_position = st.text_input(
                "🎯 " + get_text("Desired Position"),
                placeholder="Senior Software Engineer"
            )

            location = st.text_input(
                "📍 " + get_text("Current Location"),
                placeholder="City, Country"
            )

        st.markdown("### 💻 Technical Skills")
        st.markdown("""
        Please list your technical skills (one per line). For example:
        - Python
        - React
        - Node.js
        - SQL
        """)

        tech_stack_input = st.text_area(
            "Enter your technical skills",
            height=150,
            placeholder="Python\nReact\nNode.js\nSQL",
            help="List each technology on a new line. Focus on your primary skills that you're comfortable being interviewed about."
        )

        submit_col1, submit_col2, submit_col3 = st.columns([1, 2, 1])
        with submit_col2:
            submit_button = st.form_submit_button(
                "🚀 " + get_text("Start Interview"),
                use_container_width=True,
                type="primary"
            )

        if submit_button:
            if not all([full_name, email, phone, desired_position, tech_stack_input]):
                st.error("🚫 Please fill in all required fields")
                return

            tech_stack = [skill.strip() for skill in tech_stack_input.split('\n') if skill.strip()]
            if not tech_stack:
                st.error("🚫 Please enter at least one technical skill")
                return

            with st.spinner("🔄 Setting up your interview..."):
                candidate_data = {
                    "full_name": full_name,
                    "email": email,
                    "phone": phone,
                    "experience_years": experience_years,
                    "desired_position": desired_position,
                    "location": location,
                    "tech_stack": tech_stack
                }

                candidate_id = save_candidate(candidate_data)
                if candidate_id:
                    st.session_state.candidate_id = candidate_id
                    st.session_state.interview_started = True
                    st.session_state.interview_manager = InterviewManager(
                        candidate_id,
                        tech_stack,
                        st.session_state.language
                    )
                    st.rerun()
                else:
                    st.error("⚠️ You have already completed an interview. Each candidate can only interview once.")

def show_interview():
    # Show candidate info in sidebar
    if hasattr(st.session_state, 'candidate_id'):
        with st.sidebar:
            st.markdown("### 👤 Your Profile")
            skills_list = "\n".join(f"- {skill}" for skill in st.session_state.interview_manager.tech_stack)
            profile_info = f"""
            **Name:** {st.session_state.interview_manager.candidate_name}

            **Position:** {st.session_state.interview_manager.desired_position}

            **Skills:**
            {skills_list}
            """
            st.info(profile_info)

    if not hasattr(st.session_state, 'current_question'):
        with st.spinner("🔄 Generating technical questions..."):
            st.session_state.current_question = st.session_state.interview_manager.start_interview()

    if st.session_state.current_question:
        st.markdown("## 📝 Technical Question")

        # Progress indicator
        total_questions = len(st.session_state.interview_manager.questions)
        current_num = st.session_state.interview_manager.current_question + 1
        st.progress(current_num / total_questions)
        st.markdown(f"Question {current_num} of {total_questions}")

        # Question card
        st.markdown(f"""
        <div style='background-color: white; padding: 2rem; border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);'>
            <h3 style='margin-top: 0;'>{st.session_state.current_question['question']}</h3>
            <p style='color: #6B7280; margin-top: 1rem;'>Difficulty: {st.session_state.current_question.get('difficulty', 'medium')}</p>
        </div>
        """, unsafe_allow_html=True)

        # Expected concepts
        st.markdown("### 🎯 Key Concepts to Cover:")
        for concept in st.session_state.current_question['expected_concepts']:
            st.markdown(f"- {concept}")

        # Answer section
        st.markdown("### Your Answer")
        answer = st.text_area(
            "Type your answer here",
            height=200,
            key="answer_input",
            help="Provide a detailed explanation addressing all the key concepts listed above"
        )

        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            if st.button("📤 " + get_text("Submit"), type="primary", use_container_width=True):
                if not answer.strip():
                    st.error("⚠️ Please provide an answer before submitting")
                    return

                with st.spinner("🔄 Evaluating your answer..."):
                    evaluation = st.session_state.interview_manager.submit_answer(answer)

                st.markdown("### ✍️ Feedback")

                # Score indicator
                score = evaluation['score']
                if score >= 80:
                    score_color = "#059669"  # green
                elif score >= 60:
                    score_color = "#D97706"  # yellow
                else:
                    score_color = "#DC2626"  # red

                feedback_card = f"""
                <div style='background-color: white; padding: 2rem; border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);'>
                    <h3 style='color: {score_color};'>Score: {score}/100</h3>
                    <p style='margin: 1rem 0;'>{evaluation['feedback']}</p>
                """

                if 'covered_concepts' in evaluation and 'missing_concepts' in evaluation:
                    if evaluation['covered_concepts']:
                        feedback_card += "<p><strong>✅ Concepts well covered:</strong></p><ul>"
                        for concept in evaluation['covered_concepts']:
                            feedback_card += f"<li>{concept}</li>"
                        feedback_card += "</ul>"

                    if evaluation['missing_concepts']:
                        feedback_card += "<p><strong>❌ Concepts to review:</strong></p><ul>"
                        for concept in evaluation['missing_concepts']:
                            feedback_card += f"<li>{concept}</li>"
                        feedback_card += "</ul>"

                feedback_card += "</div>"
                st.markdown(feedback_card, unsafe_allow_html=True)

                if st.session_state.interview_manager.is_complete():
                    status = st.session_state.interview_manager.save_results()
                    st.session_state.interview_completed = True
                    st.rerun()
                else:
                    st.session_state.current_question = st.session_state.interview_manager.get_current_question()
                    st.rerun()

def show_results():
    st.title("🎉 Interview Results")
    score = st.session_state.interview_manager.score

    # Final score card
    result_card = f"""
    <div style='background-color: white; padding: 2rem; border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); text-align: center;'>
        <h2>Final Score: {score:.1f}/100</h2>
    </div>
    """
    st.markdown(result_card, unsafe_allow_html=True)

    if score >= 70:
        st.success("""
        ### 🌟 Congratulations!

        You have successfully passed the technical interview. 

        We will contact you via email with details about the next steps in the interview process.
        Thank you for your time and effort!
        """)
    else:
        st.info("""
        ### Thank you for participating!

        While you didn't meet our current requirements, we encourage you to:
        - 📚 Continue developing your technical skills
        - ⭐ Practice the concepts covered in the interview
        - 🔄 Apply again in the future when you feel more prepared

        Best of luck in your career journey! 🌟
        """)

def show_candidate_view():
    if not hasattr(st.session_state, 'interview_started'):
        show_candidate_registration()
    elif not hasattr(st.session_state, 'interview_completed'):
        show_interview()
    else:
        show_results()