import streamlit as st
import pandas as pd
import json
from database import get_candidate_interviews
from translations import get_text

def show_recruiter_view():
    st.title("👔 " + get_text("Recruiter Dashboard"))

    # Get interview data
    interviews = get_candidate_interviews()

    # Convert to DataFrame
    df = pd.DataFrame(
        interviews,
        columns=['Full Name', 'Email', 'Tech Stack', 'Score', 'Status', 'Interview Date']
    )

    # Process tech stack from JSON string
    df['Tech Stack'] = df['Tech Stack'].apply(lambda x: ', '.join(json.loads(x)))

    # Display statistics in cards
    st.markdown("### 📊 Overview")

    metrics_container = st.container()
    with metrics_container:
        col1, col2, col3, col4 = st.columns(4)

        with col1:
            st.markdown("""
            <div style='background-color: white; padding: 1.5rem; border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); text-align: center;'>
                <h4 style='margin: 0; color: #6B7280;'>Total Interviews</h4>
                <h2 style='margin: 0.5rem 0; color: #111827;'>{}</h2>
            </div>
            """.format(len(df)), unsafe_allow_html=True)

        with col2:
            pass_rate = (len(df[df['Status'] == 'PASSED']) / len(df) * 100) if len(df) > 0 else 0
            st.markdown("""
            <div style='background-color: white; padding: 1.5rem; border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); text-align: center;'>
                <h4 style='margin: 0; color: #6B7280;'>Pass Rate</h4>
                <h2 style='margin: 0.5rem 0; color: #111827;'>{:.1f}%</h2>
            </div>
            """.format(pass_rate), unsafe_allow_html=True)

        with col3:
            avg_score = df['Score'].mean() if len(df) > 0 else 0
            st.markdown("""
            <div style='background-color: white; padding: 1.5rem; border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); text-align: center;'>
                <h4 style='margin: 0; color: #6B7280;'>Average Score</h4>
                <h2 style='margin: 0.5rem 0; color: #111827;'>{:.1f}</h2>
            </div>
            """.format(avg_score), unsafe_allow_html=True)

        with col4:
            today_interviews = len(df[pd.to_datetime(df['Interview Date']).dt.date == pd.Timestamp.today().date()])
            st.markdown("""
            <div style='background-color: white; padding: 1.5rem; border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); text-align: center;'>
                <h4 style='margin: 0; color: #6B7280;'>Today's Interviews</h4>
                <h2 style='margin: 0.5rem 0; color: #111827;'>{}</h2>
            </div>
            """.format(today_interviews), unsafe_allow_html=True)

    # Filter section
    st.markdown("### 🔍 Filter Candidates")

    filter_container = st.container()
    with filter_container:
        col1, col2 = st.columns(2)

        with col1:
            status_filter = st.multiselect(
                "Status",
                options=['PASSED', 'FAILED'],
                default=['PASSED', 'FAILED']
            )

        with col2:
            score_threshold = st.slider(
                "Minimum Score",
                min_value=0,
                max_value=100,
                value=0,
                help="Filter candidates by minimum score"
            )

    # Apply filters
    filtered_df = df[
        (df['Status'].isin(status_filter)) &
        (df['Score'] >= score_threshold)
    ]

    # Display candidate results
    st.markdown("### 👥 Candidate Results")

    st.dataframe(
        filtered_df,
        hide_index=True,
        column_config={
            "Score": st.column_config.NumberColumn(
                "Score",
                format="%.1f",
                help="Interview score out of 100"
            ),
            "Tech Stack": st.column_config.TextColumn(
                "Technical Skills",
                help="Candidate's declared technical skills"
            ),
            "Interview Date": st.column_config.DatetimeColumn(
                "Interview Date",
                format="DD/MM/YYYY HH:mm",
                help="Date and time of the interview"
            ),
            "Status": st.column_config.SelectboxColumn(
                "Status",
                help="Interview outcome",
                options=["PASSED", "FAILED"],
                required=True
            )
        },
        use_container_width=True
    )

    # Export functionality
    if not filtered_df.empty:
        st.download_button(
            label="📥 Export Results",
            data=filtered_df.to_csv(index=False).encode('utf-8'),
            file_name='candidate_results.csv',
            mime='text/csv',
        )